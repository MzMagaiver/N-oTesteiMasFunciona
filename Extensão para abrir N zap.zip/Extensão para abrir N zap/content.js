let floatingButton = null;
let closeButton = null;
let customDDDInput = null;
let selectedNumber = '';
let needsDDD = false;
let lastCursorPosition = { x: window.innerWidth / 2, y: window.innerHeight / 2 };
let isInputActive = false; // Nova variável para controlar quando o input está ativo

// Uia só, define o browserAPI pra funcionar no Chrome ou Firefox, trem baum!
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

// Função pra mostrar o botão flutuante, uia, que capricho!
function showFloatingButton(phoneNumber, rect, requiresDDD) {
  clearFloatingElements();
  
  selectedNumber = phoneNumber;
  needsDDD = requiresDDD;

  // Cria o botão verdinho do WhatsApp, ficou foi baum!
  floatingButton = document.createElement('button');
  floatingButton.innerText = 'Abre esse Trem no WhatsApp';
  floatingButton.setAttribute('aria-label', 'Abrir número selecionado no WhatsApp');
  floatingButton.style.position = 'absolute';
  // Posiciona ao lado direito do texto selecionado
  const buttonWidth = 150; // Largura estimada do botão
  const maxX = window.innerWidth - buttonWidth - 10;
  const buttonLeft = Math.min(rect.right + window.scrollX + 5, maxX); // 5px de margem à direita
  floatingButton.style.left = `${buttonLeft}px`;
  // Ajusta para alinhar exatamente com o topo do texto selecionado
  floatingButton.style.top = `${rect.top + window.scrollY - 2}px`; // Pequeno ajuste de -2px para precisão
  floatingButton.style.zIndex = '1000';
  floatingButton.style.padding = '8px 24px 8px 8px';
  floatingButton.style.backgroundColor = '#25D366';
  floatingButton.style.color = 'white';
  floatingButton.style.border = 'none';
  floatingButton.style.borderRadius = '5px';
  floatingButton.style.cursor = 'pointer';
  floatingButton.style.fontSize = '14px';
  floatingButton.style.boxShadow = '0 2px 5px rgba(0,0,0,0.2)';
  floatingButton.style.transition = 'opacity 0.3s ease, transform 0.1s ease';
  floatingButton.style.opacity = '0';
  floatingButton.style.display = 'flex';
  floatingButton.style.alignItems = 'center';
  // Efeito de clique, nu só, que trem bonito!
  floatingButton.onmousedown = () => {
    floatingButton.style.transform = 'scale(0.95)';
  };
  floatingButton.onmouseup = () => {
    floatingButton.style.transform = 'scale(1)';
  };

  // Botão de fechar, um "X" pra limpar o trem
  closeButton = document.createElement('span');
  closeButton.innerText = '✕';
  closeButton.setAttribute('aria-label', 'Fechar botão flutuante');
  closeButton.style.position = 'absolute';
  closeButton.style.right = '8px';
  closeButton.style.fontSize = '12px';
  closeButton.style.cursor = 'pointer';
  closeButton.style.color = 'white';
  closeButton.onclick = clearFloatingElements;

  floatingButton.appendChild(closeButton);
  document.body.appendChild(floatingButton);

  // Fade-in pra ficar suave, uia!
  setTimeout(() => {
    floatingButton.style.opacity = '1';
  }, 100);

  if (needsDDD) {
    createDDDInput(rect, buttonLeft);
    floatingButton.onclick = () => {
      console.log('Botão clicado, needsDDD:', needsDDD, 'DDD digitado:', customDDDInput ? customDDDInput.value : 'Nenhum');
      const dddValue = customDDDInput.value;
      if (!/^\d{2}$/.test(dddValue)) {
        alert('Uia só, esse DDD tá errado! Bota 2 números direitinho.');
        return;
      }
      openWhatsApp(phoneNumber, dddValue);
    };
  } else {
    floatingButton.onclick = () => {
      console.log('Botão clicado, número:', phoneNumber);
      openWhatsApp(phoneNumber, '');
    };
  }
}

// Função para criar o campo de entrada de DDD, trem organizado!
function createDDDInput(rect, buttonLeft) {
  customDDDInput = document.createElement('input');
  customDDDInput.type = 'text';
  customDDDInput.placeholder = 'Digite o DDD';
  customDDDInput.maxLength = 2;
  customDDDInput.setAttribute('aria-label', 'Inserir código de área (DDD)');
  customDDDInput.style.position = 'absolute';
  // Posiciona abaixo do botão flutuante, alinhado com ele
  const inputWidth = 106; // Largura do input
  const maxX = window.innerWidth - inputWidth - 10;
  customDDDInput.style.left = `${Math.min(buttonLeft, maxX)}px`;
  customDDDInput.style.top = `${rect.top + window.scrollY + 40}px`; // 40px abaixo do botão (altura do botão + margem)
  customDDDInput.style.zIndex = '1000';
  customDDDInput.style.padding = '6px';
  customDDDInput.style.fontSize = '14px';
  customDDDInput.style.border = '1px solid #ccc';
  customDDDInput.style.borderRadius = '5px';
  customDDDInput.style.width = `${inputWidth}px`;
  customDDDInput.style.boxShadow = '0 2px 5px rgba(0,0,0,0.1)';
  customDDDInput.style.transition = 'border-color 0.2s ease';

  // Efeito de foco no input
  customDDDInput.onfocus = () => {
    isInputActive = true;
    customDDDInput.style.borderColor = '#25D366';
  };
  customDDDInput.onblur = () => {
    isInputActive = false;
    customDDDInput.style.borderColor = '#ccc';
    
    // Pequeno atraso para permitir que o clique no botão seja processado
    setTimeout(() => {
      if (!document.activeElement || 
          (document.activeElement !== customDDDInput && 
           document.activeElement !== floatingButton)) {
        // Não limpar se o foco foi para o botão
        if (!floatingButton || !floatingButton.contains(document.activeElement)) {
          // Comentado para evitar limpeza indesejada
          // clearFloatingElements();
        }
      }
    }, 100);
  };

  // Garante que só números sejam digitados
  customDDDInput.oninput = () => {
    customDDDInput.value = customDDDInput.value.replace(/[^0-9]/g, '');
  };

  document.body.appendChild(customDDDInput);
}

// Função pra abrir o WhatsApp, uia, é o coração do trem!
function openWhatsApp(phoneNumber, ddd) {
  console.log('Abrindo WhatsApp, número:', phoneNumber, 'DDD:', ddd);
  let finalNumber = phoneNumber.replace(/[^\d+]/g, '');
  if (needsDDD && ddd) {
    finalNumber = `55${ddd}${finalNumber}`;
  }
  if (!finalNumber.startsWith('+') && finalNumber.length >= 10) {
    finalNumber = `+${finalNumber}`;
  }
  console.log('Número final:', finalNumber);
  // Verifica se é número fixo (8 dígitos após DDD, total 12 com +55)
  if (finalNumber.length === 12 && !confirm('Uia só, esse trem parece um número fixo! Pode não tá no WhatsApp. Quer abrir mesmo assim?')) {
    return;
  } else if (finalNumber.length >= 13 || finalNumber.length === 12) { // Móveis (9 dígitos) ou internacionais
    const url = `https://wa.me/${finalNumber}`;
    try {
      const newWindow = window.open(url, '_blank');
      if (!newWindow) throw new Error('Janela bloqueada');
      console.log('URL aberta:', url);
    } catch (err) {
      console.error('Erro ao abrir WhatsApp:', err);
      alert('Nu só, deu ruim pra abrir o WhatsApp. Libera os pop-ups aí e tenta de novo!');
    }
  } else {
    alert('Uia, esse número tá estranho! Confere aí se tá certo.');
  }
}

// Limpa os elementos flutuantes, nu só, faxina no trem!
function clearFloatingElements() {
  if (floatingButton) {
    floatingButton.remove();
    floatingButton = null;
  }
  if (closeButton) {
    closeButton = null;
  }
  if (customDDDInput) {
    customDDDInput.remove();
    customDDDInput = null;
  }
}

// Verifica se o texto é um número de telefone, uia, que regex esperta!
function checkForPhoneNumber(text) {
  if (text.length > 25) return null;
  if (/[a-zA-Z]/.test(text)) return null; // Bloqueia texto com letras

  const phoneRegexWithDDD = /\(?(\d{2})\)?\s*(\d{4,5})-?(\d{4})/;
  const phoneRegexWithoutDDD = /(9?\d{4})-?(\d{4})/; // Aceita 8 ou 9 dígitos
  const phoneRegexInternational = /\+[1-9]\d{1,14}/;

  let phoneNumber = '';
  let requiresDDD = false;

  if (phoneRegexInternational.test(text)) {
    phoneNumber = text.replace(/[^\d+]/g, '');
  } else if (phoneRegexWithDDD.test(text)) {
    const match = text.match(phoneRegexWithDDD);
    const ddd = match[1];
    const part1 = match[2];
    const part2 = match[3];
    phoneNumber = `${ddd}${part1}${part2}`;
    
    const brazilianDDDs = ['11', '12', '13', '14', '15', '16', '17', '18', '19', '21', '22', '24', '27', '28', '31', '32', '33', '34', '35', '37', '38', '41', '42', '43', '44', '45', '46', '51', '53', '54', '55', '61', '62', '63', '64', '65', '66', '67', '68', '69', '71', '73', '74', '75', '77', '79', '81', '82', '83', '84', '85', '86', '87', '88', '89', '91', '92', '93', '94', '95', '96', '97', '98', '99'];
    
    if (!text.startsWith('+') && brazilianDDDs.includes(ddd)) {
      phoneNumber = `55${phoneNumber}`;
    } else if (!text.startsWith('+') && !brazilianDDDs.includes(ddd)) {
      return null;
    }
  } else if (phoneRegexWithoutDDD.test(text)) {
    const match = text.match(phoneRegexWithoutDDD);
    phoneNumber = `${match[1]}${match[2]}`;
    requiresDDD = true;
    if (phoneNumber.length === 9 && !match[1].startsWith('9')) {
      return null; // Rejeita números de 9 dígitos que não começam com 9
    }
  } else {
    return null;
  }

  return { phoneNumber, requiresDDD };
}

// Listener pra seleção de texto, nu só, o trem começa aqui!
document.addEventListener('selectionchange', () => {
  // Não fazer nada se o input de DDD estiver ativo
  if (isInputActive) return;
  
  const selection = window.getSelection();
  const selectedText = selection.toString().trim();
  if (!selectedText) {
    clearFloatingElements();
    return;
  }

  const phoneInfo = checkForPhoneNumber(selectedText);
  if (!phoneInfo) {
    clearFloatingElements();
    return;
  }

  const range = selection.getRangeAt(0);
  const rect = range.getBoundingClientRect();
  showFloatingButton(phoneInfo.phoneNumber, rect, phoneInfo.requiresDDD);
});

// Guarda a posição do cursor, uia, pra não perder o rastro!
document.addEventListener('mousemove', (e) => {
  lastCursorPosition = { x: e.clientX, y: e.clientY };
});

// Fecha tudo se clicar fora, nu só, limpa o trem!
document.addEventListener('mousedown', (e) => {
  // Se o input de DDD estiver com foco, não limpar os elementos
  if (customDDDInput && document.activeElement === customDDDInput) {
    return;
  }
  
  const clickedOnButton = floatingButton && floatingButton.contains(e.target);
  const clickedOnClose = closeButton && closeButton.contains(e.target);
  const clickedOnCustomInput = customDDDInput && customDDDInput.contains(e.target);
  
  if (!clickedOnButton && !clickedOnClose && !clickedOnCustomInput) {
    clearFloatingElements();
  }
});

// Limpa na rolagem, uia, pra não bagunçar o trem!
window.addEventListener('scroll', () => {
  // Não limpar se o input de DDD estiver ativo
  if (isInputActive) return;
  clearFloatingElements();
});

// Escuta mensagens do background.js, nu só, comunicação baum!
browserAPI.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'confirmFixedNumber') {
    const proceed = confirm('Uia só, esse é um número fixo e pode não tá no WhatsApp. Quer tentar abrir mesmo assim?');
    if (proceed) {
      const phoneInfo = checkForPhoneNumber(request.phoneNumber);
      if (phoneInfo && !phoneInfo.requiresDDD) {
        openWhatsApp(phoneInfo.phoneNumber, '');
      } else {
        browserAPI.runtime.sendMessage({
          message: "invalid_number",
          text: "Nu só, esse número tá esquisito ou precisa de DDD!"
        });
      }
    }
  }
});

browserAPI.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'readClipboardAndOpenWhatsApp') {
    navigator.clipboard.readText()
      .then(text => {
        console.log('Texto do clipboard recebido:', text);
        const phoneNumber = text.trim().replace(/[^\d+]/g, '');
        if (!phoneNumber) {
          alert('Uia, a área de transferência tá vazia ou inválida!');
          return;
        }
        const url = `https://wa.me/${phoneNumber}`;
        const newWindow = window.open(url, '_blank');
        if (!newWindow) {
          alert('Nu só, libera os pop-ups aí!');
        }
      })
      .catch(err => {
        console.error('Erro ao ler clipboard:', err);
        alert('Nu só, deu ruim pra ler a área de transferência!');
      });
  }
});
