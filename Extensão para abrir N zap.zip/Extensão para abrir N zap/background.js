// Uia só, define o browserAPI pra Chrome ou Firefox, trem certinho!
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

// Quando instala o trem, cria os menus de contexto, nu só!
browserAPI.runtime.onInstalled.addListener(() => {
  console.log('Extensão instalada, criando menus de contexto...');
  browserAPI.contextMenus.create({
    id: "openWhatsApp",
    title: "Abre esse Trem no WhatsApp",
    contexts: ["selection"]
  });
  browserAPI.contextMenus.create({
    id: "openWhatsAppFixed",
    title: "Esse é um número fixo que pode tá no WhatsApp também",
    contexts: ["selection"]
  });
  browserAPI.contextMenus.create({
    id: "openWhatsAppClipboard",
    title: "Abre número da Área de Transferência no WhatsApp",
    contexts: ["all"]
  });
});

// Escuta mensagens do content.js, uia, comunicação baum!
browserAPI.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'openWhatsApp') {
    console.log('Tentando abrir WhatsApp via background:', request.url);
    browserAPI.tabs.create({ url: request.url }).catch(err => {
      console.error('Nu só, deu ruim pra abrir o WhatsApp:', err);
    });
  }
});

// Quando clica no menu de contexto, uia, o trem roda!
browserAPI.contextMenus.onClicked.addListener((info, tab) => {
  console.log('Menu de contexto clicado:', info.menuItemId);
  if (info.menuItemId === "openWhatsAppFixed") {
    console.log('Enviando mensagem para content.js para número fixo:', info.selectionText);
    // Manda pro content.js pra confirmar número fixo
    browserAPI.tabs.sendMessage(tab.id, {
      action: 'confirmFixedNumber',
      phoneNumber: info.selectionText.trim()
    });
  } else if (info.menuItemId === "openWhatsAppClipboard") {
    console.log('Abrindo janela de popup para área de transferência...');
    // Abre o popup.html como uma janela independente com dimensões específicas
    browserAPI.windows.create({
      url: 'popup.html',
      type: 'popup',
      width: 403,
      height: 397,
      focused: true
    }).catch(err => {
      console.error('Erro ao abrir janela de popup:', err);
      browserAPI.runtime.sendMessage({
        message: "invalid_number",
        text: "Nu só, deu ruim pra abrir a janela! Tenta de novo."
      });
    });
  } else {
    console.log('Processando número selecionado:', info.selectionText);
    handleNumberSelection(info.selectionText.trim(), info.menuItemId);
  }
});

// Lida com o número selecionado, nu só, que regex esperta!
function handleNumberSelection(phoneNumber, menuItemId) {
  const phoneRegexWithDDD = /\(?(\d{2})\)?\s?(\d{4,5})-?(\d{4})/;
  const phoneRegexWithoutDDD = /(9?\d{4})-?(\d{4})/;
  const phoneRegexInternational = /\+[1-9]\d{1,14}/;

  const brazilianDDDs = ['11', '12', '13', '14', '15', '16', '17', '18', '19', '21', '22', '24', '27', '28', '31', '32', '33', '34', '35', '37', '38', '41', '42', '43', '44', '45', '46', '51', '53', '54', '55', '61', '62', '63', '64', '65', '66', '67', '68', '69', '71', '73', '74', '75', '77', '79', '81', '82', '83', '84', '85', '86', '87', '88', '89', '91', '92', '93', '94', '95', '96', '97', '98', '99'];

  if (menuItemId === "openWhatsApp" || menuItemId === "openWhatsAppFixed") {
    let formattedNumber = phoneNumber.replace(/[^\d+]/g, '');

    if (phoneRegexInternational.test(phoneNumber)) {
      // Número internacional, uia, abre direto!
      const url = `https://wa.me/${formattedNumber}`;
      browserAPI.tabs.create({ url }).catch(err => {
        window.open(url, '_blank');
      });
    } else if (phoneRegexWithDDD.test(phoneNumber)) {
      const match = phoneNumber.match(phoneRegexWithDDD);
      const ddd = match[1];
      const part1 = match[2];
      const part2 = match[3];
      formattedNumber = `${ddd}${part1}${part2}`;

      if (!phoneNumber.startsWith('+') && brazilianDDDs.includes(ddd)) {
        formattedNumber = `55${formattedNumber}`;
      } else if (!phoneNumber.startsWith('+') && !brazilianDDDs.includes(ddd)) {
        browserAPI.runtime.sendMessage({
          message: "invalid_number",
          text: `Nu só, esse código ${ddd} não é DDD brasileiro! Confere aí.`
        });
        return;
      }

      const url = `https://wa.me/${formattedNumber}`;
      browserAPI.tabs.create({ url }).catch(err => {
        window.open(url, '_blank');
      });
    } else if (phoneRegexWithoutDDD.test(phoneNumber)) {
      browserAPI.runtime.sendMessage({
        message: "invalid_number",
        text: "Uia, esse número tá sem DDD! Usa o botão flutuante pra escolher um."
      });
    } else {
      browserAPI.runtime.sendMessage({
        message: "invalid_number",
        text: "Nu só, esse número tá esquisito! Confere se é um telefone direitinho."
      });
    }
  }
}