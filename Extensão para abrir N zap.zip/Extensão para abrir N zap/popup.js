// Uia só, define o browserAPI pra Chrome ou Firefox, trem certinho!
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

// Quando o popup carrega, tenta ler a área de transferência
document.addEventListener('DOMContentLoaded', () => {
  console.log('Popup carregado, tentando ler área de transferência...');
  const phoneInput = document.getElementById('phoneNumber');
  const openButton = document.getElementById('openButton');

  // Lê a área de transferência
  navigator.clipboard.readText()
    .then(text => {
      console.log('Número lido da área de transferência:', text);
      const processedNumber = processPhoneNumber(text);
      phoneInput.value = processedNumber;
    })
    .catch(err => {
      console.error('Erro ao ler a área de transferência:', err);
      phoneInput.placeholder = 'Não consegui ler a área de transferência. Digite o número!';
    });

  // Adiciona listener para o botão
  openButton.addEventListener('click', openWhatsApp);
});

// Função para processar o número de telefone
function processPhoneNumber(rawNumber) {
  if (!rawNumber) return '';
  
  // Remove tudo exceto dígitos e +
  let phoneNumber = rawNumber.trim().replace(/[^\d+]/g, '');
  console.log('Número após limpeza inicial:', phoneNumber);

  // Remove zero inicial do DDD (ex.: 031971196004 → 31971196004)
  if (phoneNumber.startsWith('0') && phoneNumber.length > 1) {
    phoneNumber = phoneNumber.substring(1);
    console.log('Zero inicial removido:', phoneNumber);
  }

  // Adiciona +55 se não começar com + e tiver 10 ou 11 dígitos
  if (!phoneNumber.startsWith('+') && (phoneNumber.length === 10 || phoneNumber.length === 11)) {
    phoneNumber = `+55${phoneNumber}`;
    console.log('Adicionado +55:', phoneNumber);
  }

  return phoneNumber;
}

// Função para abrir o WhatsApp
function openWhatsApp() {
  console.log('Botão "Abrir no WhatsApp" clicado');
  const phoneInput = document.getElementById('phoneNumber');
  const phoneNumber = processPhoneNumber(phoneInput.value);

  if (!phoneNumber) {
    console.log('Nenhum número válido inserido');
    alert('Uia, nenhum número válido foi inserido! Tenta de novo.');
    return;
  }

  const url = `https://wa.me/${phoneNumber}`;
  console.log('Tentando abrir WhatsApp com URL:', url);
  browserAPI.tabs.create({ url })
    .catch(err => {
      console.error('Erro ao abrir aba do WhatsApp:', err);
      window.open(url, '_blank');
      alert('Nu só, deu ruim pra abrir o WhatsApp! Libera pop-ups e tenta de novo.');
    });
}